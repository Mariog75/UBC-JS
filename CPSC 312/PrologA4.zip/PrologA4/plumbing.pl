%%% Prolog program for the simplified plumbing example....
% Mariusz Grebelski 46406344
% Copyright David L Poole 2018.
% This work is licensed under a Creative Commons
% Attribution-NonCommercial-ShareAlike 4.0 International License.
% See: http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en_US.

% The dynamic declaration prevents undefined predicate errors.
:- dynamic on_t1/0, on_t2/0, off_t1/0, off_t2/0, plugged_bath/0,
	   unplugged_bath/0, plugged_sink/0, unplugged_sink/0, flow_d1/0, on_t3/0, off_t3/0,
		 on_t4/0, off_t4/0.

% See assignment description for the intended interpretation of the symbols
pressurized_p1.
pressurized_p2 :- on_t1, pressurized_p1.
flow_shower :- on_t2, pressurized_p2.
wet_bath :- flow_shower.
flow_d2 :- wet_bath, unplugged_bath.
flow_d1 :- flow_d2.

% (a)
pressurized_p3 :- on_t1, pressurized_p1.
flow_sink :- on_t3, pressurized_p3.
wet_sink :- flow_sink.
flow_d3 :- wet_sink, unplugged_sink.
flow_d1 :- flow_d3.

% (b)
wet_floor :- flow_shower, plugged_bath.
wet_floor :- flow_sink, plugged_sink.

% (c) Hot water taps
flow_shower :- on_t4.
flow_sink :- on_t4.

% You can change the status of taps and plugs by adding or removing (commenting out) statements:
off_t1.
on_t2.
off_t3.
on_t4.
unplugged_bath.
unplugged_sink.
