% Silly example for CPSC 312, 2018, Assignment 4
% Mariusz Grebelski 46406344
:- dynamic slithy/0, toves/0, brillig/0, gyre/0, gimble/0, wabe/0,
	   mome/0, raths/0, mimsy/0, outgrabe/0, vorpal/0, manxome/0, jubjub/0.

slithy :- toves, brillig.
slithy :- gyre, gimble, wabe.
toves :- outgrabe, vorpal.
toves :- manxome.
brillig :- jubjub.
outgrabe.
vorpal :- manxome.
gyre :- manxome.
gyre :- outgrabe.
manxome.
gimble :- outgrabe.
gimble:- brillig.
gimble :- vorpal.
wabe.
